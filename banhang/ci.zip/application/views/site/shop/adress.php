


<div class="tab-catalog" style="width: 1340px; margin: 0px auto; height: auto;">
    <div class="container">
        <div class="row" style="margin-left: 300px; margin-top: 10px;">
            <h2 class="fa fa-spinner"> Thông tin shop <i>NatulieShop - Đà Nẵng</i></h2><br />
            <h3 class="fa fa-facebook-square"> facebook: https://www.facebook.com/tuixachmyphamdanang/?ref=settings</h3><br />
            <h3 class="fa fa-check-square"> Chuyên cung cấp túi xách xỉ và lẻ, mỹ phẩm xuất xứ thailand 100%, giá cả và chất lượng luôn cam kết tốt nhất cho khách hàng</h3><br />
            <h3 class="fa fa-check-square"> Địa chỉ 1: Kiệt 382 Tôn Đức Thắng, Hòa Khánh, Thành Phố Đà nẵng</h3><br />
            <h3 class="fa fa-check-square"> Địa chỉ 2: 78 Võ Như Hưng, Ngũ Hành Sơn, Thành Phố Đà nẵng</h3>
            <i class="fa fa-volume-control-phone"> Điện thoại: 0905770963 - 01674717919</i><br />
            <i class="fa fa-envelope-o"> Email: xuongtuidanang@gmail.com</i><br />
            <i class="fa fa-hand-pointer-o"> Website: https://www.xuongtuidanang.net/</i><br />
            <img src="<?php echo base_url('upload/logos/2.png') ?>">
        </div>
    </div>
</div>
<style>
    div.row h2{
        font-size: 15px;
        border-bottom: 2px solid #003399;
        width: 300px;
        padding-bottom: 4px;
        font-weight: 800;
        color: #000;
    }
    div.row h3{
        font-size: 14px;
        color: #000;
        padding-left: 5px;
    }
    div.row i{
        color: #000;
        padding: 5px;

    }
</style>