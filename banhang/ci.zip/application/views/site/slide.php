
<div class="container">
<?php $this->load->view('site/message', $this->data); ?>
    <div class="row margin-0">
        <div class="col-sm-12 col-md-12 col-lg-3 padding-0 hidden-md hidden-sm hidden-xs"></div>
        <div class="col-sm-12 col-md-12 col-lg-9 padding-0" style="float: right;">
            <div class="kt_home_slide slide-home5 nav-center" data-nav="true"  data-autoplay="true" data-loop="true" data-responsive='{"0":{"items":"1"},"768":{"items":"1","nav":false},"992":{"items":"1"}}'>
                <div class="item-slide" data-background="<?php echo base_url('upload'); ?>/sliders/18.jpg" data-height="405" data-reponsive='{"320":280,"400":480,"768":400,"1024":465}'>

                </div>
                <div class="item-slide" data-background="<?php echo base_url('upload'); ?>/sliders/19.jpg"  data-height="405"  data-reponsive='{"320":280,"400":480,"768":400,"1024":465}'>

                </div>
            </div>
        </div>
    </div>
</div>