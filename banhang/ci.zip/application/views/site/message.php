<?php
    if(isset($message)) {
        ?>
        <label style="margin-left: 120px; !important;"> <?php echo $message; ?></label>
        <?php
    }
?>

