<div class="section-home-slide">
    <?php $this->load->view('site/slide'); ?>
</div>

<div class="margin-top-30">
    <?php $this->load->view('site/bill'); ?>
</div>

<div class="container">
    <?php $this->load->view('site/home/content_top'); ?>
</div>

<div class="section-eeeeee margin-top-50 padding-bottom-50">
    <?php $this->load->view('site/home/content_center'); ?>
</div>