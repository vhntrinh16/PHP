
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="box-icon style4 margin-bottom-25">
                    <div class="icon">
                        <span class="icon-font pe-7s-plane"></span>
                    </div>
                    <div class="box-content">
                        <h3 class="title">GIAO HÀNG TOÀN QUỐC</h3>
                        <span class="subtitle">Miễn phí trong 2km</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="box-icon style4 margin-bottom-25">
                    <div class="icon">
                        <span class="icon-font pe-7s-headphones"></span>
                    </div>
                    <div class="box-content">
                        <h3 class="title">HỖ TRỢ 24/7</h3>
                        <span class="subtitle">Nhiệt tình hỗ trợ</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="box-icon style4 margin-bottom-25">
                    <div class="icon">
                        <span class="icon-font pe-7s-refresh-2"></span>
                    </div>
                    <div class="box-content">
                        <h3 class="title">HOÀN TRẢ SAU 2 TUẦN</h3>
                        <span class="subtitle">Thông tin hoàn trả</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
