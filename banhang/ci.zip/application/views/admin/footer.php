<div id="footer">
    <div class="wrapper">Bản quyền © 2012-2016 hocphp.info</div>
</div>