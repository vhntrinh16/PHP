<?php
if(isset($message)) {
    ?>
    <div class="nNote nInformation hideit">
        <p><strong>Thông báo: </strong><?php echo $message; ?></p>
    </div>
    <?php
}
?>

