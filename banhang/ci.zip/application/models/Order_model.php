<?php
    class Order_model extends MY_Model{
        var $table = 'order';
        var $key = 'id_order';
    }
?>