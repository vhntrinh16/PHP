<?php
    class Product_model extends MY_Model{
        var $table = 'product';
        var $key = 'id_product';
    }
?>