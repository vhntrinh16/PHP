﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('uicolor','de',{uicolor:{title:'UI Pipette',preview:'Live-Vorschau',config:"Fügen Sie diese Zeichenfolge in die 'config.js' Datei.",predefined:'Vordefinierte Farbsätze'}});
